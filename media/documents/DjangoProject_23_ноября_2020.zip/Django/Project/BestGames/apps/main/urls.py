from django.urls import path
from . import views
from . views import SearchResultView


app_name = 'main'

urlpatterns = [
	path("", views.GameView.as_view()),
	path('cart/', views.CartView.as_view(), name='cart'),
	path('search/', SearchResultView.as_view(), name='search_results'),
	path('<int:main_id>/', views.GameDetailView.as_view(), name = 'detail'),
	path('<int:main_id>/like', views.like, name = 'like'),
    path('<int:main_id>/dislike', views.dislike, name = 'dislike'),
    path('<int:main_id>/leave_comment/', views.leave_comment, name = 'leave_comment'),
	path('category/<slug:url>/', views.GameCategoryView.as_view(), name='game_category_view'),
	path('userprofile/<int:user_id>', views.userprofile_get_info, name='userprofile_get_info'),
	path('userprofile/<int:user_id>/userprofile_set_info', views.userprofile_set_info, name='userprofile_set_info'),
	path('add-to-cart/<int:main_id>', views.AddToCartView.as_view(), name='add-to-cart'),
]
