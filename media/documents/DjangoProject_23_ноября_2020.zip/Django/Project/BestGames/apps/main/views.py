
from django.http import Http404, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.views.generic.base import View
from django.views.generic import ListView
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q

from . models import Customer, Category, Game, CartProduct, Cart, Comment
from django.contrib.auth.models import User



class CartView(View):

	'''=============='''
	'''    Корзина   '''
	'''=============='''

	def get(self, request, *args, **kwargs):

		user = User.objects.get(username=request.user)
		cart = Cart.objects.get(owner=Customer.objects.get(user_id=request.user))

		return render(request, "main/cart.html", {"cart": cart})



class AddToCartView(View):

	'''======================================='''
	'''   Система добавления игры в корзину   '''
	'''======================================='''

	def get(serl, request, *args, **kwargs):

		main_id = kwargs.get('main_id')
		customer = Customer.objects.get(user=request.user)
		cart = Cart.objects.get(owner=customer)
		product = Game.objects.get(id = main_id)

		cart_product, created = CartProduct.objects.get_or_create(
			user=cart.owner, cart=cart, product=product, final_price=product.price
		)

		cart.products.add(cart_product)

		return HttpResponseRedirect('/cart/')



class GameView(View):

	'''==============================='''
	'''   Вывод страниц c пагинацией  '''
	'''==============================='''

	def get(self, request):
		
		games = Game.objects.order_by('-id')

		paginator = Paginator(games, 12)

		page = request.GET.get('page') 

		try:
		    posts = paginator.page(page)
		except PageNotAnInteger:
		    posts = paginator.page(1)
		except EmptyPage:
			posts = paginator.page(paginator.num_pages)

		return render(request, "main/list.html", {"games": games, 'page': page, 'posts': posts})



class GameCategoryView(View):

	'''==============================='''
	'''   Вывод страниц c пагинацией   '''
	'''==============================='''

	def get(self, request, url):

		try:
			category = Category.objects.get(slug=url)
			games = Game.objects.filter(category__slug = url)
		except:
			raise Http404(f'Игры c категориями: "{url}" не найдена.')

		paginator = Paginator(games, 12)

		page = request.GET.get('page') 

		try:
		    posts = paginator.page(page)

		except PageNotAnInteger:
		    posts = paginator.page(1)

		except EmptyPage:
			posts = paginator.page(paginator.num_pages)

		return render(request, "main/list.html", {"games": games, 'page': page, 'category': category, 'posts': posts})



class GameDetailView(View):

	'''==============================='''
	'''    Вывод детальной страницы   '''
	'''==============================='''

	def get(self, request, main_id):

		userprofile_list = Customer.objects.order_by('-id')
		games = Game.objects.get(id = str(main_id))

		games.views += 1
		games.save()

		latest_comments_list = games.comment_set.order_by('-id')[:50]
		return render(request, 'main/detail.html', {'games':games, 'userprofile_list': userprofile_list, 'latest_comments_list': latest_comments_list})



class SearchResultView(ListView):

	'''============================'''
	'''       Система пойска       '''
	'''============================'''

	model = Game
	template_name = 'main/list.html'

	def get_queryset(self):

		query = self.request.GET.get('q')

		object_list = Game.objects.filter(Q(title__icontains=query) | Q(gameplay_description__icontains=query) | Q(story_description__icontains=query))

		return object_list



def like(request, main_id):

	'''============================'''
	'''      Система дизлайков     '''
	'''============================'''

	if str(main_id) in request.COOKIES:
		return HttpResponseRedirect('/')
	else:
		main = Game.objects.get(id = str(main_id) ) 
		main.like += 1 
		main.save()
		response = HttpResponseRedirect('/')
		response.set_cookie(str(main_id), 'like')
		return response



def dislike(request, main_id):

	'''============================'''
	'''       Система лайков       '''
	'''============================'''

	if str(main_id) in request.COOKIES:
		return HttpResponseRedirect('/')
	else:
		main = Game.objects.get(id = str(main_id) )
		main.dislike += 1 
		main.save() 
		response = HttpResponseRedirect('/')
		response.set_cookie(str(main_id), 'dislike')
		return response



def userprofile_get_info(request, user_id):

	'''=============================='''
	'''   Передача данных в шаблон   '''
	'''=============================='''

	userprofile = Customer.objects.get(id = user_id)

	return render(request, "customer/account.html", {'userprofile': userprofile})



def userprofile_set_info(request, user_id, *args):

	'''===================================================='''
	'''   Сохранение и редактирование данных пользователя  '''
	'''===================================================='''

	userprofile = Customer.objects.get(id = user_id)

	if request.POST.get('phone') != '':
		userprofile.phone = request.POST.get('phone')
		userprofile.save()
	
	if request.POST.get('email') != '':
		userprofile.user.email = request.POST.get('email')
		userprofile.user.save()
	
	if request.POST.get('address') != '':
		userprofile.address = request.POST.get('address')
		userprofile.save()
	
	if request.POST.get('image') != '':
		userprofile.image = request.POST.get('image', 'user/drakon_klassika_svet_blesk_poverhnost_fon_16050_1280x1024')
		userprofile.save()

	return HttpResponseRedirect( reverse('main:userprofile_get_info', args = (userprofile.id,)) )



def leave_comment(request, main_id):

	'''==============================='''
	'''      Система комментариев     '''
	'''==============================='''

	try:
		a = Game.objects.get(id = main_id )
	except:
		raise Http404('Статья не найдена!')
		
	a.comment_set.create(author_name = request.POST['name'], comment_text = request.POST['text'])

	return HttpResponseRedirect( reverse('main:detail', args = (a.id,)) )