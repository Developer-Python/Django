
from django.db.models.signals import post_save
from django.dispatch import receiver

from django.db import models
from django.contrib.auth.models import User



class Customer(models.Model):

	user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='related_user')
	phone = models.CharField(verbose_name='Номер телефона', max_length=11)
	address = models.CharField(verbose_name='Адрес', max_length=80)
	image = models.ImageField(verbose_name='Аватарка', upload_to='user/')

	def __str__(self):
		return self.user.username
	
	class Meta:
		verbose_name = 'Пользователь'
		verbose_name_plural = 'Пользователи'



class Category(models.Model):

	name = models.CharField(verbose_name='Категория', max_length=200)
	slug = models.SlugField(unique=True)

	def __str__(self):
		return self.name

	class Meta:
		verbose_name = 'Категорий'
		verbose_name_plural = 'Категорий'



class Game(models.Model):

	title = models.CharField('Название', max_length=60)
	title_description = models.CharField('Описание на обложке', max_length=100)
	gameplay_description = models.TextField('Геймплей')
	story_description = models.TextField('Сюжет')
	game_features_description = models.TextField('Игровые особенности')
	language_text = models.CharField('Язык текста', max_length=25)
	language_voise = models.CharField('Язык озвучки', max_length=25)
	os = models.CharField('Операцеонная система', max_length=50)
	cpu = models.CharField('Процессор', max_length=50)
	ram = models.CharField('Оперативка', max_length=50)
	gpu = models.CharField('Видеокарта', max_length=50)
	hard_disk = models.CharField('Жёсткий диск', max_length=50)
	data = models.IntegerField('Дата выхода', default=0)
	category = models.ManyToManyField(Category, verbose_name='Категорий')
	image_1 = models.ImageField('1) Изображение из игры', upload_to='game/')
	image_2 = models.ImageField('2) Изображение из игры', upload_to='game/')
	image_3 = models.ImageField('3) Изображение из игры', upload_to='game/')
	image_4 = models.ImageField('4) Изображение из игры', upload_to='game/')
	image_wrapper = models.ImageField('Обложка', upload_to='game/')
	torrent = models.FileField('Torrent файл', upload_to='documents/')
	like = models.IntegerField('Нравиться', default='0')
	dislike = models.IntegerField('Не нравиться', default='0')
	views = models.IntegerField('Просмотры', default='0')
	pro = models.CharField('PRO', max_length=1)
	price = models.DecimalField(max_digits=9, decimal_places=2, verbose_name='Стоймость игры')
	slug = models.SlugField(unique=True)


	def __str__(self):
		return self.title

	class Meta:
		verbose_name = 'Игра'
		verbose_name_plural = 'Игры'



class CartProduct(models.Model):

	user = models.ForeignKey('Customer', verbose_name='Покупатель', on_delete=models.CASCADE)
	cart = models.ForeignKey('Cart', verbose_name='Корзина', related_name='related_products', on_delete=models.CASCADE)
	product = models.ForeignKey(Game, verbose_name='Игра', on_delete=models.CASCADE)
	qty = models.PositiveIntegerField(default=1)
	final_price = models.DecimalField(max_digits=9, decimal_places=2, verbose_name='Общая цена')

	def __str__(self):
		return 'Продукт: {} (для корзины)'.format(self.product.title)

	class Meta:
		verbose_name = 'Продукт корзины'
		verbose_name_plural = 'Продукт корзины'



class Cart(models.Model):

	owner = models.ForeignKey('Customer', verbose_name='Владелец', on_delete=models.CASCADE)
	products = models.ManyToManyField(CartProduct, blank=True, related_name='related_cart')
	total_product = models.PositiveIntegerField(default=0)
	final_price = models.DecimalField(max_digits=9, decimal_places=2, verbose_name='Общая цена')

	def __str__(self):
		return str(self.id)
	
	class Meta:
		verbose_name = 'Корзина'
		verbose_name_plural = 'Корзина'



class Comment(models.Model):

	games = models.ForeignKey(Game, on_delete=models.CASCADE)
	userprofile = models.ForeignKey(Customer, on_delete=models.CASCADE)
	author_name = models.CharField('Имя автора', max_length=25)
	comment_text = models.CharField('Коментарий', max_length=100)
	comment_time = models.DateTimeField('дата коментария', auto_now=True)

	def __str__(self):
		return self.author_name

	class Meta:
		verbose_name = 'Коментарий'
		verbose_name_plural = 'Коментарии к играм'



@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
	if created:
		Customer.objects.create(user=instance, image='user/1.jpg')

